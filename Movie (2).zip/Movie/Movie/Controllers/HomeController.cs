﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Movie.Data;
using Movie.Models;
using Movie.Models.ViewModels;
//using Movie.Areas.Identity.Data;

namespace Movie.Controllers
{
    public class HomeController : Controller
    {
        private ApplicationDbContext _context;
        int count = 1;
        bool flag = true;
        //private UserManager<ApplicationUser> _usermanager;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
            //_usermanager = usermanager;
        }




        [HttpGet]
        public IActionResult BookNow(int Id)
        {
            BookNowViewModel vm = new BookNowViewModel();
            var item = _context.MovieDetails.Where(a => a.Id == Id).FirstOrDefault();
            vm.Movie_Name = item.Movie_Name;
            vm.Movie_date = item.DateAndTime;
            vm.MovieId = Id;

            return View(vm);
        }

        [HttpPost]
        public IActionResult BookNow(BookNowViewModel vm)
        {
            List<BookingTable> booking = new List<BookingTable>();
            List<Cart> carts = new List<Cart>();
            string seatno = vm.SeatNo.ToString();
            int movieId = vm.MovieId;

            string[] seatnoArray = seatno.Split(',');
            count = seatnoArray.Length;
            if (checkseat(seatno, movieId) == false)
            {
                foreach (var item in seatnoArray)
                {
                    carts.Add(new Cart { Amount = 150, MovieId = vm.MovieId, date = vm.Movie_date, seatno = item });
                }
                foreach (var item in carts)
                {
                    _context.Cart.Add(item);
                    _context.SaveChanges();
                }
                TempData["Success"] = "Sear no Booked, Check your Cart";

            }
            else
            {
                TempData["seatnomsg"] = "Please Change your Seat no";
            }
            return RedirectToAction("BookNow");
        }

        private bool checkseat(string seatno, int movieId)
        {
            //throw new NotImplementedException();
            string seats = seatno;
            string[] seatreserve = seats.Split(',');
            var seatnolist = _context.BookingTable.Where(a => a.MovieDetailsId == movieId).ToList();
            foreach (var item in seatnolist)
            {
                string alreadybook = item.seatno;
                foreach (var item1 in seatreserve)
                {
                    if (item1 == alreadybook)
                    {
                        flag = false;
                    }
                }
            }
            if (flag == false)
                return true;
            else
                return false;


        }

        [HttpPost]
        public IActionResult checkseat(DateTime Movie_date, BookNowViewModel booknow)
        {
            string seatno = string.Empty;
            var movielist = _context.BookingTable.Where(a => a.DatetoPresent == Movie_date).ToList();
            if (movielist != null)
            {
                var getseatno = movielist.Where(b => b.MovieDetailsId == booknow.MovieId).ToList();
                if (getseatno != null)
                {
                    foreach(var item in getseatno)
                    {
                        seatno = seatno + " " + item.seatno.ToString();
                    }
                    TempData["SNO"] = "Already Booked" + seatno;
                }
            }
            return View();
        }




        public IActionResult Index()
        {
            var getMovieList = _context.MovieDetails.ToList();
            return View(getMovieList);
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
